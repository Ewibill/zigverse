# Stomata Breathing — ZigGlow S1 · notes

**The lawful climate stage.** One stomata, breathing because it decides to.

---

## What this proves

The law: *nothing controls the organism; everything only changes its world.*

Crystal Root broke that law — audio drove the shader directly, so the audience
watched a **reaction**. Here the loop is intact:

```
ZigSense      breath  (world's own rhythm  +  your hold / space)
   │           writes CO₂ + humidity INTO THE AIR — never into the aperture
   ▼
ZigField      GPU float texture   R = CO₂   G = humidity   B = light
   │           diffuses + relaxes toward ambient on its own
   ▼
ZigCoupling   the stomata SAMPLES the field at its own location (true readback)
   ▼
Organism      turgor — a spring-damped physiology — DECIDES to open
              latency · inertia · hysteresis · resting drift · micro-life
```

The half-second of lag between your breath and its opening is not a bug to tune
out. That beat is where "alive" lives. Breath is weather; the leaf is a body.

---

## What the ENGINE gained (this is the point, not the leaf)

Four reusable capabilities, none leaf-specific:

1. **Respiration-through-climate** — breath → atmosphere → organism reads field →
   organism acts. Kelp and Rootwhale inherit this whole path unchanged.
2. **A field-sampling coupling** — an organism perceiving a shared world at its own
   coordinate. Works for one cell or ten thousand.
3. **A turgor / "decide-to-act" behavior** — a spring-damped integrator with a want
   (`wants()`), a decision (`update()`), hysteresis, and a living baseline. This is a
   general *should I change state?* organ. It has nothing to do with stomata.
4. **A GPU ZigField that carries multiple independent channels** — CO₂ and humidity
   ride the breath; light runs its own circadian day the breath never touches.

The `Stomata` class already carries an `agency` knob it doesn't use yet — that's the
Stage-2 soloist seam, sitting dormant.

---

## Restraint decisions (against Scout's guide)

Kept the concept, pulled the drama down per the standing verdict:

- **No red panic / OVERWHELMED state.** A leaf that visibly panics tells the audience
  how to feel. Overwhelm should land as a flinch, not a scream — a later stage will do
  it as a tightening + dimming, sensed not announced.
- **No seven-stage scripted journey.** The states aren't a timeline to play back;
  they *emerge* from the field. Resting → waking → breathing happens because the air
  changed, not because a clock advanced.
- **The interior stays mysterious.** The sub-stomatal cavity glows by a whisper, never
  a reveal. "Reveals too much" — so it doesn't.
- **Near-black.** InfoComm range. The organism emerges from darkness.

The input-mapping table in the guide read as direct control (CC2 → opening amount).
Every line was flipped to atmospheric change (CC2 → CO₂ + humidity in the air). Same
words on the page; opposite architecture.

---

## Reading the proof (press `d`)

The debug overlay shows the lawful causality as live bars:

```
ZigField    CO₂ / humidity / light   ← the air the stomata reads
Organism    wants  ← physiology's target from that air
            turgor ← what it actually does, LAGGING the want on purpose
```

Watch `turgor` chase `wants` chase the field chase your breath. Four links, each
lagging the last. That chain is the organism thinking.

---

## Controls

- **hold anywhere** — exhale onto the air at that spot (breath diffuses to the leaf)
- **space** — breathe directly at the stomata, hands-free (for performing)
- **d** — toggle the pulse (debug causality read-out)

Runs autonomously with no input: the world breathes on its own at rest.

---

## Habitat Requirements (draft, S1)

- **Render node:** eyeZ-class, WebGL2 + `EXT_color_buffer_float` (RTX 5070 Ti confirmed).
- **Signal path:** Chrome → Spout2 → TouchDesigner → 12G-SDI out (production chain).
- **Grayscale / brightness floor:** near-black; wants a processor that holds shadow
  detail (Brompton Tessera calibration anchor). The whole piece lives below mid-grey.
- **Live input (future tier):** CC2 at 60 Hz maps into `ZigSense.b1` — one hook,
  already shaped as breath-into-air. No architecture change to go live.

---

## Stage 2 (next pull, not yet built)

- **Population.** Instance the `Stomata` class across the leaf, all sampling the one
  ZigField. Neighbor ripple falls out for free — they share the air.
- **The protagonist.** Raise `agency` on one cell: it reads the same field but wants
  harder and settles slower — leads, lags, or rebels against the others. The soloist
  seam is already in the class.
- **Then, and only then,** touch color and the deeper cavity. Life first, always.

Built the engine. Let the species emerge from it.
