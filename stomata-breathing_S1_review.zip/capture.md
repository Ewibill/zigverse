# capture.md — Stomata Breathing S1

For the review `capture.mp4`. Full-res, no proxy.

## Setup
- eyeZ, Chrome fullscreen (F11), `index.html`. Let it settle ~10s so the resting
  rhythm is established before recording.
- Debug overlay OFF for the beauty pass. One separate pass ON, to document the loop.

## Beauty pass (~40–60s)
1. **Rest** (~8s) — hands off. Show it living on its own: the slow drift, dew,
   the world's quiet breath. This is the baseline the audience must trust first.
2. **First breath** (~10s) — one slow **space**-hold exhale. The point of the whole
   piece: hold, wait, and let it open *after* you. Do not rush the release — the lag
   is the shot.
3. **Breathing together** (~15s) — a few unhurried breaths, varied length. Never
   metronomic. Let it overshoot slightly and settle.
4. **Return to rest** (~10s) — hands off, let it close on its own back toward night.

Goosebumps test: does the release of your breath and the leaf's opening feel like
*it* decided? If it feels puppeted, we tune latency, not the visual.

## Proof pass (~15s)
Press `d`. One breath. Record the bars: field rises → `wants` rises → `turgor`
follows, lagging. That's the lawful loop on camera for the AV integrator brief.

## Notes for the log
- Which breath lengths read as most alive?
- Does the resting state hold attention with no input, or go dead? (If dead,
  `restBreathAmount` / `microLife` in `CFG`.)
- Interior glow — still mysterious, or creeping toward "reveals too much"?
