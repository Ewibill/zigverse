# ZC.Ambience — the Atmosphere Bus (spec v0.1, for review)

**One line:** MIDI drives the *organism*; Ambience lets your *processed sound* drive the *environment the organism lives in* — a second stream, connected by breath, different in kind, recombined per file.

This is a spec to react to **before** wiring. Nothing here is built yet. The mapping table (§4) is the part to mark up.

---

## 0. Where we already are

Two of the three pieces exist:

- **The organism bus (MIDI) is done.** Web MIDI → notes + CC2 breath → `ZC.Perf`, `ZC.Pacemaker`, Note→Form. The creature's behavior is fully performance-driven and deterministic.
- **The raw air extractor is done.** `ZC.Timbre` already opens the interface input (MOTU M2) and distills the sound into three tested channels, all `0..1`, dual-envelope smoothed, with pure math in `_analyze()` (Node-testable) and L/R split voices:
  - `body` — RMS loudness (how much horn is in the room)
  - `brightness` — spectral centroid, log 200 Hz → 8 kHz (growl ↔ shine)
  - `flux` — positive spectral change (articulation/flutter, fires between MIDI notes)

**So Ambience is not a new DSP engine.** It is (a) a few added features Timbre doesn't yet compute, and (b) the environment-mapping layer that turns the feature vector into world motion — kept strictly separate from the organism so any file recombines them.

---

## 1. The two-bus contract

| | Nervous System bus | Atmosphere bus |
|---|---|---|
| Source | MIDI (EWI sensors) | Audio (EWI → Logic + FX → interface) |
| Reads | note, breath CC2, bend, timing | timbre, energy, spectral motion, tail |
| Drives | the **organism** — behavior, life-forces | the **environment** — medium, light, space |
| Character | sharp, instant, symbolic, replayable | smooth, decaying, textural, continuous |
| Status | built | Timbre built · Ambience = this spec |

They stay separate in code precisely so they can be **recombined**: `organism.subscribe(MIDI)`, `environment.subscribe(Ambience)`. The connection between them is that they share one breath; the difference is that one is gesture and the other is timbre.

---

## 2. The feature vector

`ZC.Ambience.read()` returns one small, stable, normalized struct per frame. Three channels come straight from Timbre; four are new.

| Feature | Source | Measures | DSP | Smoothing | Perceptual meaning |
|---|---|---|---|---|---|
| `energy` | Timbre.body | overall drive | RMS of time-domain | fast attack / med release | how much sound fills the room |
| `brightness` | Timbre.brightness | tone color | spectral centroid, log 200→8k | medium | airy/shine ↔ dark/growl |
| `flux` | Timbre.flux | articulation | positive spectral change | fast | how fast the timbre is moving |
| `noisiness` | **new** | breath vs pitch | spectral flatness (geo/arith mean) + ZCR | medium | breathy/turbulent ↔ pure/glassy |
| `low` / `high` | **new** | spectral balance | band-summed magnitude (≈<250 Hz / >2 kHz) | medium | depth/body ↔ air/brilliance |
| `tail` | **derived** | resonance/decay | slow-release follower on `energy` | slow release only | how long the sound rings after you stop |
| `onset` | **derived** | attack impulse | `flux` thresholded → decaying spike | impulse + fast decay | a sharp transient just happened |

Notes:
- Everything is `0..1`. `onset` is a one-shot impulse that decays; the rest are continuous.
- **Auto-calibration:** each continuous feature runs a slow running-normalization so it's plug-and-play across input gains — no per-session tuning. (Timbre's `flux` is already scale-invariant; `body`/`brightness` get a slow AGC.)
- `noisiness` is the one genuinely new *perceptual* axis — it's how we tell breathy playing from pure tone, which MIDI cannot express at all.

---

## 3. The forcing-function principle (why the world feels alive, not puppeted)

Audio must **not** paint the environment frame-by-frame like a level meter. Each environment parameter is a **leaky integrator** the audio *perturbs*; the parameter relaxes toward its base on its own:

```
dP/dt = -k · (P − Pbase) + gain · feature
```

Your sound *stirs* a medium that has its own inertia and decay. That's what makes the environment **unique** (its own emergent settling) while staying **connected** (your breath is what stirs it). Emergence over scripting — same law as the organisms. Every mapping in §4 is applied through this idiom, with its own `k` (how quickly the world forgets) chosen per lever.

---

## 4. The mapping table  ← **react to this**

Audio feature → environment lever → the **real engine knob** it writes (all already exist: `ZigCore.Env` MEDIUM/FORCES/CURRENT, boundary, the sky/fog/light uniforms, memory-glass) → curve → intent.

| Feature | Environment lever | Engine knob | Curve | Intent |
|---|---|---|---|---|
| `brightness` | **color temperature** of sky & light | `skyTop`/`horizon` hue, `sunCol` warm↔cold | bipolar about neutral | bright tone → warm, luminous world; dark tone → cold, deep |
| `energy` | **luminosity + medium density** | ambient/moon gain, MEDIUM `drag`, fog | gamma (soft knee) | louder playing lights the space and thickens the air |
| `noisiness` | **atmospheric grain / mist** | fog density + particulate grain term | linear | breathy → misty, textured air; pure tone → clear glass |
| `flux` | **current turbulence** | CURRENT `gyre`/`eddy` gain, FORCES `damp` | linear + threshold | timbral motion stirs the medium; a held color lets it settle |
| `low` | **deep pulse / space swell** | boundary radius breathe, ground glow | slow | low-end heaves the floor and the volume of the world |
| `high` | **shimmer aloft** | upper-medium sparkle gain | linear | brilliance sparkles the top of the space |
| `tail` | **afterglow persistence** | memory-glass afterimage `tau` (the E/D dial) | decay → tau | your reverb's actual decay = how long the world holds your light |
| `onset` | **flash / bloom** | brief luminosity + current impulse | impulse w/ decay | a sharp attack flashes the space, like lightning in the medium |

Two things to weigh in on:
1. **Are these the right pairings?** e.g. should `brightness` steer *color* (my pick) or *light direction*? Should `noisiness` be *fog* or *turbulence*?
2. **How hard should each push?** The `gain`/`k` per row is the "how much" — we tune those live once there's signal; the table just sets *what connects to what*.

---

## 5. The creative leverage — divergence

The buses agree most of the time (shared breath), but the **artistic instrument is the gap between them**, and it comes from their different time-constants:

- The **organism responds to MIDI's sharp edges** — note-off stills the body *instantly*.
- The **environment responds to audio's decaying envelopes** — `tail` keeps the world ringing *after* the note is gone.

So: you stop playing, the creature falls still — and the world keeps glowing on your reverb's tail. The environment *remembers* what the creature just did. That call-and-response only exists because you have two streams of different character; it's un-fakeable from one. `onset` gives the opposite pole — a hit that flashes the world ahead of the settling body.

---

## 6. API & reusability

```
ZC.Ambience.arm(deviceHint)      // wraps Timbre.arm — one input, both buses
ZC.Ambience.update(dt)           // once per real frame, like Perf/Timbre
ZC.Ambience.read() -> {energy, brightness, flux, noisiness, low, high, tail, onset}

ZC.AmbienceMap.apply(scene, profile?)   // writes the §4 levers into the scene's
                                        // environment uniforms via leaky integrators
```

- **One capability, every world inherits it.** Rootwhale, Kelp, Zigpede, the LA28 pieces all `apply` the same bus; a `profile` lets each world spend the features differently (a lakebed reads `low` as depth; open air reads it as a gust).
- **Byte-identical when not armed.** No audio → features sit at rest → the leaky integrators hold each lever at its static base → the environment is exactly today's environment. Opt-in, like every Zig capability.
- Ambience never touches the organism path. The separation is the point.

---

## 7. Verification (fits the existing ethos)

- **Pure-math ref test** (`ambience_ref.mjs`): feed synthesized frames → assert features. Sine → low `noisiness`, known `brightness`; white noise → high `noisiness`; impulse → `onset` fires; ramp-down → `tail` decays. (Same pattern as the existing `timbre_ref`.)
- **Mapping ref test**: leaky-integrator math is pure → assert a feature step drives its lever and relaxes.
- **Headless boot**: an environment demo armed with a synthetic stream compiles and runs clean; unarmed demo stays byte-identical.
- **Deterministic replay**: record a feature log once, replay it to reproduce a run exactly (audio itself isn't replayable — the *feature vector* is).

---

## 8. Build phases

1. **Features** — add `noisiness`, `low`/`high`, derive `tail`/`onset` in `_analyze`; `ambience_ref` green.
2. **Mapping** — `ZC.AmbienceMap` + the §4 table through leaky integrators; one demo environment (a creature in a medium your tone makes).
3. **Tune live** — you play through Logic + FX; we set the per-row gains by ear/eye. This is where the Director judges.
4. **Generalize** — a `profile` per world so every environment inherits the bus its own way.

Meanwhile (parallel, not blocking): the Mac→eyeZ audio path — Logic main out → interface → an input on eyeZ → Chrome — so there's real signal for phase 3.

---

*Mark up §4 and §5 — the pairings and the divergence — and I'll build phases 1–2 against your notes.*
